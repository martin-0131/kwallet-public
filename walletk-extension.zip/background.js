/**
 * Opens the Side Panel when the extension icon is clicked.
 * Side Panel stays open across tab switches and external clicks.
 */
chrome.action.onClicked.addListener((tab) => {
  if (tab?.windowId != null) {
    chrome.sidePanel.open({ windowId: tab.windowId });
  }
});
